function Torneo(){
    window.location.href = "pages/torneo.html";
}

function Promo(){
    window.location.href = "pages/promo.html";
}

function Estudio(){
    window.location.href = "pages/estudio.html";
}

function Articulos(){
    window.location.href = "pages/articulos.html";
}

function Diversion(){
    window.location.href = "pages/diversion.html";
}

function Entrevista(){
    window.location.href = "pages/entrevista.html";
}

function Instagram(){
    window.open("https://www.instagram.com/colegiopadrearrupeoficial/", "_blank");
}

function GoBack(){
    window.location.href = "../index.html";
}
