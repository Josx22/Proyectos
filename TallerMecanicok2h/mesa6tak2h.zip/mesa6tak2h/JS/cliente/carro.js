const closeButton = document.querySelector('.close-button');
const confirmButton = document.querySelector('.confirm-button');

closeButton.addEventListener('click', () => {
   
    console.log('Cerrar carrito');
});

confirmButton.addEventListener('click', () => {
    
    console.log('Confirmar pedido');
});