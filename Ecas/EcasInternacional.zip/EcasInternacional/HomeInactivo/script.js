function toggleContent() {
    const content = document.getElementById("hiddenContent");
    const arrow = document.querySelector(".flecha");
    
    if (content.style.display === "none") {
      content.style.display = "block";
      arrow.textContent = "▲"; 
    } else {
      content.style.display = "none";
      arrow.textContent = "▼"; 
    }
  }

  function toggleContentt() {
    const content = document.getElementById("hiddenContentt");
    const arrow = document.querySelector(".flechaa");
    
    if (content.style.display === "none") {
      content.style.display = "block";
      arrow.textContent = "▲"; 
    } else {
      content.style.display = "none";
      arrow.textContent = "▼"; 
    }
  }
  

  
  let isUserLoggedIn = false;

  
  const submitButton = document.getElementById("submitButton");
  const sessionMessage = document.getElementById("sessionMessage");

  
  function iniciarSesion() {
    isUserLoggedIn = true; n
    verificarEstadoSesion();
  }

 
  function verificarEstadoSesion() {
    if (isUserLoggedIn) {
      submitButton.disabled = false; 
      sessionMessage.textContent = ""; 
    } else {
      submitButton.disabled = true; 
      sessionMessage.textContent = "Por favor, inicie sesión para habilitar el botón.";e
    }
  }

  // Llama a la verificación inicial
  verificarEstadoSesion();