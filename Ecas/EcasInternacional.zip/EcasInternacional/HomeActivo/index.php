<?php

include("../Conexión.php"); 


$message = ""; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = isset($_POST['nombre']) ? $_POST['nombre'] : null;
    $correo = isset($_POST['correo_electronico']) ? $_POST['correo_electronico'] : null;
    $telefono = isset($_POST['numero_telefono']) ? $_POST['numero_telefono'] : null;
    $servicio = isset($_POST['servicio_seleccionado']) ? $_POST['servicio_seleccionado'] : null;
    $informacion = isset($_POST['informacion']) ? $_POST['informacion'] : null;

    if ($nombre && $correo && $telefono && $servicio) {
        $stmt = $conn->prepare("INSERT INTO form_data (nombre, correo_electronico, numero_telefono, servicio_seleccionado, informacion) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $nombre, $correo, $telefono, $servicio, $informacion);
        if ($stmt->execute()) {
            $message = "Datos enviados correctamente.";
        } else {
            $message = "Error al enviar los datos: " . $stmt->error;
        }
        $stmt->close();
    } else {
        $message = "Por favor, completa todos los campos obligatorios.";
    }
    $conn->close();
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ECAS International Business</title>
  <link rel="icon" type="image/png" sizes="32x32" href="favicon-32x32.png">

  <link rel="stylesheet" href="EstiloActivo.css">
  <link rel="stylesheet" href="cuadros1.css">
  <link rel="stylesheet" href="cuadro2.css">
  <script src="script.js"></script>
</head>
<body>
<div>

    <div class="contact">
      <img class="what" src="Imágenes/imagen_2024-12-11_212531089-removebg-preview.png" alt="">
      <p class="phead">
        <a href="https://wa.me/50322951014?text=Hola,%20quiero%20solicitar%20más%20información%20más%20información" target="_blank">+503 2295-1014</a>

      </p>
      
  </div>
  <header>
    <div class="servicios">
      <nav>
        <div class="logo-menu">
          <img src="Imágenes/NUEVO LOGO ECAS.png" class="logo" alt="Logo">
          <ul class="menu">
            <li><a href="#welcome">Inicio</a></li>
            <li><a href="#Nuestro">Nuestro trabajo</a></li>
            <li><a href="#nuestros">Nuestros servicios y productos</a></li>
          </ul>
        </div>
        
      
      </nav>
    </div>
  </header>
  
  

  <main>
    <section id="welcome">
      <h1 class="H1Bien">¡Bienvenido!</h1>
      <p class="interesado">¿Interesado en nuestros servicios? <a href="#Formulario" class="masinfo">Solicita más información aquí</a>.</p>
      <div class="icons">
        <div class="icon">
          <img src="Imágenes/IconApoyar.png" alt="Handshake" class="Handshake">
        </div>
        <div class="icon">
          <img src="Imágenes/IconEquipo.png" alt="Group" class="Group">
        </div>
        <div class="icon">
          <img src="Imágenes/IconIcon3.png" alt="Computer" class="Computer">
        </div>
      </div>
      
    </section>
    <div class="espacio2"></div>
    <div class="espacio">

    </div>
<div><h1 id="Nuestro">Nuestro trabajo</h1></div>
<div class="section-title">¿Quiénes somos?</div>
<div>
    <p class="expertos">
        Expertos en servicios de trámites y asesoría aduanera. Contamos con un equipo capacitado para realizar el trabajo, con empeño y confianza. Además, ofrecemos asesoría aduanera, para que su trámite se realice de acuerdo a su necesidad, para brindar el mejor servicio. Contamos con la confianza del mayor porcentaje de empresas, importadoras de encomienda familiar a El Salvador.
    </p>
</div>

<div class="section-title">Misión y Visión</div>

  <div class="containerMisionyVision">
   
    <div class="card">
      <div class="card-inner">
      
        <div class="card-front">
          <h3>Misión</h3>
        </div>
       
        <div class="card-back">
          <p>Brindar servicios de calidad en trámites aduaneros de importación y logística, apoyados en la
            experiencia obtenida a través de los años de servicios de la empresa.</p>
        </div>
      </div>
    </div>

   
    <div class="card">
      <div class="card-inner">
        
        <div class="card-front">
          <h3>Visión</h3>
        </div>
       
        <div class="card-back">
          <p>Ser una empresa reconocida por la trayectoria en servicios aduaneros y de logística, a través de la
            calidad en los servicios ofrecidos.</p>
        </div>
      </div>
    </div>
  </div>
</body>
</html>

  </main>
</div>
<div class="espacio3">

</div>
<div>
  <h1 id="nuestros">
    Nuestros servicios y productos 
    <p class="flecha" onclick="toggleContent()">▼</p>
  </h1>
</div>
<div id="hiddenContent" style="display: none; padding: 20px; background-color: #f9f9f9;">
  <div class="fondo">
    <div class="cuadros">
      <h2>Trámites aduanales de importación y exportación</h2>
    </div>
    <div class="cuadros2">
      <h2>Tramite de registro en CIEX (BCR)</h2>
    </div>
    <div class="cuadros3">
      <h2>Tramites de permisos importación en los diferentes ministerios, (Ministerio de Salud, Dirección Nacional de Medicamentos, Ministerio de Agricultura y Ganadería, Ministerio de Defensa, etc.</h2>
    </div>
    <div class="cuadros4">
      <h2>Fletes terrestres</h2>
    </div>
    <div class="cuadros5">
      <h2>Expertos en el Manejo y Tramite de Encomiendas Familiares Maritima-Terreste, Menaje de Casa y Equipajes.</h2>
    </div>
    <div class="cuadros6">
      <h2>Venta de Vehículos Importados y sus partes</h2>
    </div>
  </div>
</div>

<div>
  <h1 class="nuestros">
    Nuestros servicios aduaneros 
    <p class="flechaa" onclick="toggleContentt()">▼</p>
  </h1>
</div>
<div id="hiddenContentt" style="display: none; padding: 20px; background-color: #f9f9f9;">
  <div class="fondos">
    <div class="cuadross">
      <h2>Asesoría aduanera</h2>
    </div>
    <div class="cuadross2">
      <h2>Desaduanaje de mercancía y vehículos</h2>
    </div>
    <div class="cuadross3">
      <h2>Importación, Exportación y Regímenes Especiales (Encomiendas, Franquicias, Menajes de Casa, Etc)</h2>
    </div>
    <div class="cuadross4">
      <h2>Elaboración de Tránsitos (Internos y Duca-T)</h2>
    </div>
    <div class="cuadross5">
      <h2>Tramites de permisos especiales para la importación o exportación en diferentes dependencias de Gobierno(CIEX, MISAL, DNM, MAG, etc)</h2>
    </div>
  
  </div>
</div>

<section id="Formulario">
  <h2>Obten más información sobre nuestros servicios</h2>
  <div class="card-formulario">
    <img src="Imágenes\IconDespacho-de-aduana.png" alt="ImagenFormulario" class="form-image">
    <h1>Lideramos el camino en soluciones aduaneras con experiencia y compromiso</h1>
    <p>
      Llena el formulario y selecciona el servicio deseado. Nos comunicaremos contigo a la brevedad para brindarte más información.
    </p>
    <form action="#" method="post">
      <input type="text" name="nombre" placeholder="Nombre completo" required>
      <input type="email" name="correo_electronico" placeholder="Correo electrónico" required>
      <input type="tel" name="numero_telefono" placeholder="Número telefónico" required>


       <label for="servicio_seleccionado">Seleccione el servicio del que desea información</label>


       <select id="servicio_seleccionado" name="servicio_seleccionado" required>

        <option value="" disabled selected>-- Seleccione un servicio --</option>

        <option value="Trámites aduanales de importación y exportación">Trámites aduanales de importación y exportación</option>
        <option value="Tramite de registro en CIEX (BCR)">Tramite de registro en CIEX (BCR)</option>
        <option value="Tramites de permisos importación en los diferentes ministerios, (Ministerio de Salud, Dirección Nacional de Medicamentos, Ministerio de Agricultura y Ganadería, Ministerio de Defensa, etc.">Tramites de permisos importación en los diferentes ministerios, (Ministerio de Salud, Ministerio <br>de <br> Agricultura y Ganadería, Ministerio de Defensa, etc.</option>
        <option value="Fletes terrestres">Fletes terrestres</option>
        <option value="Expertos en el Manejo y Tramite de Encomiendas Familiares Maritima-Terreste, Menaje de Casa y Equipajes.">Expertos en el Manejo y Tramite de Encomiendas Familiares Maritima-Terreste, Menaje de Casa y Equipajes.</option>
        <option value="Venta de Vehículos Importados y sus partes">Venta de Vehículos Importados y sus partes</option>

        <option value="Asesoría aduanera">Asesoría aduanera</option>
        <option value="Desaduanaje de mercancía y vehículos">Desaduanaje de mercancía y vehículos</option>
        <option value="Importación, Exportación y Regímenes Especiales (Encomiendas, Franquicias, Menajes de Casa, Etc)">Importación, Exportación y Regímenes Especiales (Encomiendas, Franquicias, Menajes de Casa, Etc)</option>
        <option value="Elaboración de Tránsitos (Internos y Duca-T)">Elaboración de Tránsitos (Internos y Duca-T)</option>
        <option value="Tramites de permisos especiales para la importación o exportación en diferentes dependencias de Gobierno(CIEX, MISAL, DNM, MAG, etc)">Tramites de permisos especiales para la importación o exportación en diferentes dependencias de Gobierno(CIEX, MISAL, DNM, MAG, etc)</option>
      </select>

      <textarea name="informacion" placeholder="Información extra" rows="4"></textarea>


      <button type="submit">Enviar</button>
    </form>
    <br>
    <p style="margin-top: 0px; color: red; font-weight: bold;"><?php echo $message; ?></p> 
    
</section>

<section class="clientes">
  <h3>Nuestros clientes</h3>
  <div class="logosClientes">
    <img src="Clientes/PaqueteriaLatina.png" alt="Paqueteria-Latina">
    <img src="Clientes/UrgenteExpress.png" alt="Urgente-Express">
    <img src="Clientes/HR.png" alt="HR-Express">
    <img src="Clientes/Guatemex.png" alt="Envios-Guatemex">
    <img src="Clientes/Carbonero.png" alt="El-Carbonero">
  </div>
</section>
    
  
<footer>
   <div class="footer">
    <div class="Void">
      <div class="footer-container">
        <div class="footer-item">
          <img src="Imágenes/NUEVO LOGO ECAS.png" alt="Logo ECAS" class="footer-logo">
      </div>
     
      <div class="footer-item">
          <img src="Imágenes/ImagenUbicación.png" alt="Icono ubicación" class="footer-image">
          <p>Carr. Panamericana Km 11 1/2,<br>Local 3-A. Ilopango, San Salvador</p>
      </div>
  
      <div class="footer-item">
          <img src="Imágenes/ImagenTelefono.png" alt="Icono teléfono" class="footer-image">
          <p>Fijo: 2295-1014<br>Celular: 6111-1419</p>
      </div>
   
      <div class="footer-item">
          <img src="Imágenes/ImageCorreo.png" alt="Icono correo" class="footer-image">
          <p>atencion@ecas.com.sv<br>ecasinternacional@hotmail.com</p>
          </div>
      </div>
    </div>
  </div>
    <div class="footer-bottom">
        <p>&copy; 2024 Ecas Internacional Business, Sociedad Anónima de Capital Variable. Todos los derechos reservados.</p>
    </div>
  
</footer>


</body>
</html>