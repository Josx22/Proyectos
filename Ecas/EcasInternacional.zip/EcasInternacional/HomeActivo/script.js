function toggleContent() {
    const content = document.getElementById("hiddenContent");
    const arrow = document.querySelector(".flecha");
    
    if (content.style.display === "none") {
      content.style.display = "block";
      arrow.textContent = "▲"; 
    } else {
      content.style.display = "none";
      arrow.textContent = "▼"; 
    }
  }

  function toggleContentt() {
    const content = document.getElementById("hiddenContentt");
    const arrow = document.querySelector(".flechaa");
    
    if (content.style.display === "none") {
      content.style.display = "block";
      arrow.textContent = "▲"; // Cambia la flecha hacia arriba
    } else {
      content.style.display = "none";
      arrow.textContent = "▼"; // Cambia la flecha hacia abajo
    }
  }