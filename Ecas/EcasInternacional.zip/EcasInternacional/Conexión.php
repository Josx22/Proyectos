

<?php

$servidor_bd = 'localhost';
$usuario_bd = 'root';
$contraseña_bd = '';
$nombre_bd = 'ecasinternacionalbusiness';

$conn = new mysqli($servidor_bd, $usuario_bd, $contraseña_bd, $nombre_bd);


if ($conn -> connect_error) {
    die("Conexión fallida:" . $conn -> connect_error);
}

$conn -> set_charset("utf8mb4");
?>

