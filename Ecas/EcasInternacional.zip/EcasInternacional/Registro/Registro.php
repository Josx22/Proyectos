<?php
include("../Conexión.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $usuario = $_POST['usuario'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    
    if (empty($usuario) || empty($email) || empty($password)) {
        $error_message = "Todos los campos son obligatorios.";
    } else {
        
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error_message = "Correo electrónico no válido.";
        } else {
           
            $check_sql = "SELECT * FROM cliente WHERE usuario = ? OR email = ?";
            $stmt = $conn->prepare($check_sql);
            $stmt->bind_param("ss", $usuario, $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $error_message = "El nombre de usuario o el correo electrónico ya está registrado. Por favor elige otro.";
            } else {
               
                $sql = "INSERT INTO cliente (usuario, email, password) VALUES (?, ?, ?)";
                $stmt = $conn->prepare($sql);
                $hashed_password = password_hash($password, PASSWORD_BCRYPT); 
                $stmt->bind_param("sss", $usuario, $email, $hashed_password);

                if ($stmt->execute()) {
                  
                    header("Location: ../HomeActivo/index.php");
                    exit();
                } else {
                    $error_message = "Error en el registro: " . $stmt->error;
                }
            }
        }
    }

    if (isset($stmt)) {
        $stmt->close();
    }
}


$conn->close();
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Registro.css">
    <link rel="icon" type="image/png" sizes="32x32" href="Imágenes/favicon-32x32.png">
    <title>ECAS Internacional Business</title>
    <style>
        input[type="email"]{
    padding: 10px;
    margin: 10px auto;
    background-color: #e5e5e5;
    border: 1px solid #716b6b;
    border-radius: 5px;
    font-size: 14px;
    width: 100%;

}
    </style>
</head>
<body>
    <header>
        <img src="Imágenes/NUEVO LOGO ECAS.png" alt="Logo ECAS" class="logo">
    </header>
    
    <div class="container">
        <div class="tabs">
            <a href="../Inicio/inicio.php" class="tab">Iniciar Sesión</a>
            <a href="Registro.php" class="tab activo">Registrarse</a>
        </div>
        
        <form action="" method="POST" class="login-form">
            <label for="usuario">Crea tu usuario</label>
            <input type="text" id="usuario" name="usuario" placeholder="Crea tu usuario" required>
            
            <label for="correo">Correo electrónico</label>
            <input type="email" id="email" name="email" placeholder="Escribe tu dirección de correo electrónico" required>
            
            <div class="password-container">
                <label for="contraseña">Contraseña</label>
                <input type="password" id="password" name="password" placeholder="Escribe tu contraseña" required>
                
                <div class="show-password">
                    <input type="checkbox" id="show-password">
                    <label for="show-password">Mostrar contraseña</label>
                </div>
            </div>
            
            <script>
           
                const showPasswordCheckbox = document.getElementById('show-password');
                const passwordField = document.getElementById('password');
                showPasswordCheckbox.addEventListener('change', function () {
                    passwordField.type = this.checked ? 'text' : 'password';
                });
            </script>
            
            <button type="submit" class="login-button">
              Registrarse
            </button>

        </form>

        <?php if (isset($error_message)): ?>
            <p style="color: red;"><?php echo $error_message; ?></p>
        <?php endif; ?>
        
        <footer class="footer">
            <p>Regístrate para comenzar a gestionar tus trámites seguros con nosotros.</p>
        </footer>
    </div>
    
    <footer class="copyright">
        <p>© 2024 Ecas Internacional Business, Sociedad Anónima de Capital Variable. Todos los derechos reservados.</p>
    </footer>
</body>
</html>
