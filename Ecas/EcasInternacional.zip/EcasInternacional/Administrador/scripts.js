console.log("scripts.js cargado correctamente");
document.addEventListener('DOMContentLoaded', () => {
    listarFormularios('desc'); 
});

function listarFormularios(order = 'desc') {
    fetch(`listar_formularios.php?order=${order}`)
        .then(response => response.json())
        .then(data => {
            const tabla = document.getElementById('tabla-formularios');
            tabla.innerHTML = ''; 

            if (data.length > 0) {
                data.forEach(formulario => {
                    const fila = document.createElement('tr');
                    fila.innerHTML = `
                        <td>${formulario.nombre}</td>
                        <td>${formulario.servicio_seleccionado}</td>
                        <td>${formulario.fecha_envio}</td>
                        <td>
                            <button onclick="verMas(${formulario.id})">Ver más</button>
                            <button onclick="cambiarEstado(${formulario.id})">
                                ${formulario.estado === 'Pendiente' ? 'Marcar Revisado' : 'Revisado'}
                            </button>
                        </td>
                    `;
                    fila.id = `fila-${formulario.id}`;
                    tabla.appendChild(fila);

                
                    const detalleFila = document.createElement('tr');
                    detalleFila.id = `detalle-${formulario.id}`;
                    detalleFila.classList.add('detalle', 'oculto');
                    detalleFila.innerHTML = `
                        <td colspan="4">
                            <div id="contenido-${formulario.id}">Cargando...</div>
                        </td>
                    `;
                    tabla.appendChild(detalleFila);
                });
            } else {
                tabla.innerHTML = '<tr><td colspan="4">No hay registros disponibles.</td></tr>';
            }
        })
        .catch(error => console.error('Error al listar formularios:', error));
}
function verMas(id) {
    const detalleRow = document.getElementById(`detalle-${id}`);
    const contenido = document.getElementById(`contenido-${id}`);

    if (!detalleRow.classList.contains('oculto')) {
        detalleRow.classList.add('oculto');
        return;
    }

    detalleRow.classList.remove('oculto');

    fetch(`detalles_formulario.php?id=${id}`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                contenido.innerHTML = `<p class="error">${data.error}</p>`;
            } else {
                contenido.innerHTML = `
                    <table>
                        <tr>
                            <th>Nombre</th>
                            <td>${data.nombre}</td>
                        </tr>
                        <tr>
                            <th>Correo</th>
                            <td>${data.correo_electronico}</td>
                        </tr>
                        <tr>
                            <th>Teléfono</th>
                            <td>${data.numero_telefono}</td>
                        </tr>
                        <tr>
                            <th>Servicio</th>
                            <td>${data.servicio_seleccionado}</td>
                        </tr>
                        <tr>
                            <th>Información Extra</th>
                            <td>${data.informacion}</td>
                        </tr>
                        <tr>
                            <th>Fecha de Envío</th>
                            <td>${data.fecha_envio}</td>
                        </tr>
                    </table>
                `;
            }
        })
        .catch(error => {
            contenido.innerHTML = `<p class="error">Error al cargar los detalles.</p>`;
        });

    marcarComoVisto(id);
}

function marcarComoVisto(id) {
    fetch('backend.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `action=marcar-visto&id=${id}`
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const fila = document.getElementById(`fila-${id}`);
                fila.classList.remove('no-visto');
                fila.querySelector('.visto').textContent = 'Visto';
            } else {
                console.error('Error al marcar como visto:', data.error);
            }
        })
        .catch(error => console.error('Error al marcar como visto:', error));
}


function marcarComoVisto(id) {
    fetch('backend.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `action=marcar-visto&id=${id}`
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const fila = document.getElementById(`fila-${id}`);
                const vistoSpan = fila.querySelector('.visto');
                fila.classList.remove('no-visto');
                vistoSpan.textContent = 'Visto';
            } else {
                console.error('No se pudo marcar como visto:', data.error);
            }
        })
        .catch(error => console.error('Error al marcar como visto:', error));
}


function cambiarEstado(id) {
    fetch('backend.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `action=cambiar-estado&id=${id}`
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Estado cambiado correctamente.');
                const fila = document.getElementById(`fila-${id}`);
                const estadoSpan = fila.querySelector('.estado');
                const botonEstado = fila.querySelector('button:last-child');

                
                if (data.estado === 'Pendiente') {
                    estadoSpan.textContent = 'Pendiente';
                    estadoSpan.className = 'estado pendiente';
                    botonEstado.textContent = 'Marcar Revisado';
                } else {
                    estadoSpan.textContent = 'Revisado';
                    estadoSpan.className = 'estado revisado';
                    botonEstado.textContent = 'Marcar Pendiente';
                }
            } else {
                alert('No se pudo cambiar el estado.');
            }
        })
        .catch(error => console.error('Error al cambiar estado:', error));
}


function buscarFormulario() {
    const input = document.getElementById('search-input').value.trim();

    if (input === '') {
        alert('Por favor, ingresa un término de búsqueda.');
        return;
    }

    fetch(`buscar_formulario.php?query=${encodeURIComponent(input)}`)
        .then(response => response.json())
        .then(data => {
            const tabla = document.getElementById('tabla-formularios');
            tabla.innerHTML = ''; 

            if (data.error) {
                tabla.innerHTML = `<tr><td colspan="6" class="mensaje-error">${data.error}</td></tr>`;
            } else {
                data.forEach(formulario => {
                    const fila = document.createElement('tr');
                    fila.id = `fila-${formulario.id}`;
                    fila.className = formulario.visto ? '' : 'no-visto'; 
                    fila.innerHTML = `
                        <td>${formulario.nombre}</td>
                        <td>${formulario.servicio_seleccionado}</td>
                        <td>${formulario.fecha_envio}</td>
                        <td>
                            <span class="estado ${formulario.estado.toLowerCase()}">
                                ${formulario.estado}
                            </span>
                        </td>
                        <td>
                            <span class="visto">${formulario.visto ? 'Visto' : 'No visto'}</span>
                        </td>
                        <td>
                            <button onclick="verMas(${formulario.id})">Ver más</button>
                            <button onclick="cambiarEstado(${formulario.id})">
                                ${formulario.estado === 'Pendiente' ? 'Marcar Revisado' : 'Marcar Pendiente'}
                            </button>
                        </td>
                    `;
                    tabla.appendChild(fila);

                    
                    const detalleFila = document.createElement('tr');
                    detalleFila.id = `detalle-${formulario.id}`;
                    detalleFila.classList.add('detalle', 'oculto');
                    detalleFila.innerHTML = `
                        <td colspan="6">
                            <div id="contenido-${formulario.id}">Cargando...</div>
                        </td>
                    `;
                    tabla.appendChild(detalleFila);
                });
            }
        })
        .catch(error => {
            console.error('Error en la búsqueda:', error);
            const tabla = document.getElementById('tabla-formularios');
            tabla.innerHTML = `<tr><td colspan="6" class="mensaje-error">Ocurrió un error al realizar la búsqueda.</td></tr>`;
        });
}
