<?php
include '../Conexión.php';

if ($_POST['action'] === 'cambiar-estado' && isset($_POST['id'])) {
    $id = intval($_POST['id']);
    $sql = "UPDATE form_data SET estado = 'Revisado', visto = 1 WHERE id = $id";

    if ($conn->query($sql)) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => $conn->error]);
    }
    exit;
}

