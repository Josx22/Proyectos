<?php
include '../Conexión.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $id = intval($_POST['id']);

    if ($action === 'marcar-visto') {
       
        $sql = "UPDATE form_data SET visto = 1 WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $id);

        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Error al actualizar el estado']);
        }
        exit;
    }

    if ($action === 'cambiar-estado') {
        
        $sql = "SELECT estado FROM form_data WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $nuevoEstado = ($row['estado'] === 'Pendiente') ? 'Revisado' : 'Pendiente';

            $updateSql = "UPDATE form_data SET estado = ? WHERE id = ?";
            $updateStmt = $conn->prepare($updateSql);
            $updateStmt->bind_param('si', $nuevoEstado, $id);

            if ($updateStmt->execute()) {
                echo json_encode(['success' => true, 'estado' => $nuevoEstado]);
            } else {
                echo json_encode(['success' => false, 'error' => 'Error al actualizar el estado']);
            }
        } else {
            echo json_encode(['success' => false, 'error' => 'Formulario no encontrado']);
        }
        exit;
    }
}
?>

