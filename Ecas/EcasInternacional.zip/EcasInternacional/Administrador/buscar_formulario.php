<?php

include '../Conexión.php';

header('Content-Type: application/json');


if (isset($_GET['query'])) {
    $query = "%" . $conn->real_escape_string($_GET['query']) . "%";

    
    $sql = "SELECT id, nombre, servicio_seleccionado, fecha_envio, estado, visto 
            FROM form_data 
            WHERE nombre LIKE ? 
               OR correo_electronico LIKE ? 
               OR servicio_seleccionado LIKE ? 
            ORDER BY fecha_envio DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('sss', $query, $query, $query);
    $stmt->execute();
    $result = $stmt->get_result();

    $formularios = [];
    while ($row = $result->fetch_assoc()) {
        $formularios[] = $row;
    }

    if (count($formularios) > 0) {
        echo json_encode($formularios);
    } else {
        echo json_encode(['error' => 'No se encontraron resultados.']);
    }

    $stmt->close();
} else {
    echo json_encode(['error' => 'No se proporcionó ningún término de búsqueda.']);
}

$conn->close();
?>
