<?php

include '../Conexion.php';

$order = isset($_GET['order']) && $_GET['order'] === 'asc' ? 'ASC' : 'DESC';


$sql = "SELECT id, nombre, servicio_seleccionado, fecha_envio FROM form_data ORDER BY fecha_envio $order";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $formularios = [];
    while ($row = $result->fetch_assoc()) {
        $formularios[] = $row;
    }
    echo json_encode($formularios); 
} else {
    echo json_encode([]);
}

$conn->close();
?>
