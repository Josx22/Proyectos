<?php

include '../Conexión.php';


$sql = "SELECT id, nombre, servicio_seleccionado, fecha_envio, estado, visto FROM form_data ORDER BY fecha_envio DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Administrador.css">
    <script src="scripts.js"></script>


    <title>Registros</title>
</head>
<body>
    <header>
        <img src="Imágenes/NUEVO LOGO ECAS.png" alt="Logo ECAS" class="logo">
        <nav>
            <a href="../Administrador/Admin.php">Registros de Formularios</a>
            
        </nav>
        <div class="search-bar">
         <input type="text" id="search-input" placeholder="Buscar...">
         <button onclick="buscarFormulario()">Buscar</button>
       </div>

        
    </header>
    
    <h1>Formularios</h1>
    <table>
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Servicio</th>
                <th>Fecha de Envío</th>
                <th>Estado</th>
                <th>Visto</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody id="tabla-formularios">
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr id="fila-<?php echo $row['id']; ?>" class="<?php echo $row['visto'] ? '' : 'no-visto'; ?>">
                        <td><?php echo htmlspecialchars($row['nombre']); ?></td>
                        <td><?php echo htmlspecialchars($row['servicio_seleccionado']); ?></td>
                        <td><?php echo htmlspecialchars($row['fecha_envio']); ?></td>
                        <td>
                            <span class="estado <?php echo strtolower($row['estado']); ?>">
                                <?php echo htmlspecialchars($row['estado']); ?>
                            </span>
                        </td>
                        <td>
                            <span class="visto"><?php echo $row['visto'] ? 'Visto' : 'No visto'; ?></span>
                        </td>
                        <td>
                            <button onclick="verMas(<?php echo $row['id']; ?>)">Ver más</button>
                            <button onclick="cambiarEstado(<?php echo $row['id']; ?>)">
                                <?php echo $row['estado'] === 'Pendiente' ? 'Marcar Revisado' : 'Marcar Pendiente'; ?>
                            </button>
                        </td>
                    </tr>
                    <tr class="detalle oculto" id="detalle-<?php echo $row['id']; ?>">
                      <td colspan="6">
                            <div id="contenido-<?php echo $row['id']; ?>" class="detalle-contenido">
                             Cargando...
                            </div>
                        </td>
                    </tr>

                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6">No hay registros disponibles.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <?php $conn->close(); ?>
</body>
</html>
