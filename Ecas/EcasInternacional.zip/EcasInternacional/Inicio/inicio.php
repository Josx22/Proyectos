<?php
session_start();

include("../Conexión.php"); 

$error = ''; 

if ($_SERVER["REQUEST_METHOD"] == 'POST') {
    $usuarioOcorreo = $_POST['usuarioOcorreo']; 
    $password = $_POST['password'];

    $sql = "SELECT * FROM cliente WHERE usuario = ? OR email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $usuarioOcorreo, $usuarioOcorreo); 
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $usuario = $result->fetch_assoc();
       
        if (password_verify($password, $usuario['password'])) {
            $_SESSION['usuario'] = $usuario['usuario'];
            $_SESSION['rol'] = $usuario['rol'];

            
            if ($usuario['rol'] === 'admin') {
                header("Location: ../Administrador/Admin.php");
            } else {
                header("Location: ../HomeActivo/index.php");
            }
            exit(); 
        } else {
            $error = "Contraseña incorrecta.";
        }
    } else {
        $error = "Usuario o correo no encontrado.";
    }

    $stmt->close();
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ECAS Internacional Business</title>
    <link rel="stylesheet" href="Inicio.css">
    <link rel="icon" type="image/png" sizes="32x32" href="Imágenes\favicon-32x32.png">
</head>
<body>
    
    <header>
        <img src="Imágenes/NUEVO LOGO ECAS.png" alt="Logo ECAS" class="logo">
    </header>

    <div class="container">
        <div class="tabs">
            <a href="inicio.php" class="tab active">Iniciar Sesión</a>
            <a href="../Registro/Registro.php" class="tab">Registrarse</a>
        </div>

      
        <form class="login-form" method="POST" action="inicio.php">
            <label for="usuario">Ingrese su usuario o dirección de correo electrónico</label>
            <input type="text" id="usuarioOcorreo" name="usuarioOcorreo" placeholder="Escriba su usuario o dirección de correo electrónico" required>


            <div class="password-container">
                <label for="password">Contraseña:</label>
                <input type="password" id="password" name="password" placeholder="Escribe tu contraseña" required>

                <div class="show-password">
                    <input type="checkbox" id="show-password">
                    <label for="show-password">Mostrar contraseña</label>
                </div>
            </div>
            


            <script>
                
                const showPasswordCheckbox = document.getElementById('show-password');
                const passwordField = document.getElementById('password');

                showPasswordCheckbox.addEventListener('change', function () {
               
                    passwordField.type = this.checked ? 'text' : 'password';
                });
            </script>

            <button type="submit" class="login-button">Iniciar Sesión</button>
        </form>
        <br>
      
        <?php if (!empty($error)) : ?>
         <div class="error-message"><?php echo $error; ?></div>
        <?php endif; ?>


        <footer class="footer">
            <p>¡Bienvenido de vuelta! Estamos listos para ayudarte.</p>
        </footer>
    </div>

    <footer class="copyright">
        <p>© 2024 Ecas Internacional Business, Sociedad Anónima de Capital Variable. Todos los derechos reservados.</p>
    </footer>
</body>
</html>
