    using System;
    using System.Windows.Forms;

    namespace Uso_De_Una_Matriz_De_3x3
    {
    public partial class Form1 : Form
    {
        
        public class ParametrosTrafico
        {
            public double Velocidad { get; set; }
            public double TiempoEspera { get; set; }
            public double Flujo { get; set; }
            public int CantidadVehiculos { get; set; }
        }

        // Matriz bidimensional: [intersecciones, tipos de veh�culos]
        ParametrosTrafico[,] matrizTrafico = new ParametrosTrafico[10, 3];

        public Form1()
        {
            InitializeComponent();
        }



        private void Form1_Load(object sender, EventArgs e)
        {
            cbtipoinfo.DropDownStyle = ComboBoxStyle.DropDownList;
            cbtipovehiculo.DropDownStyle = ComboBoxStyle.DropDownList;
            
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    matrizTrafico[i, j] = new ParametrosTrafico();
                }
            }

            
            cbtipovehiculo.Items.Add("Autom�vil");
            cbtipovehiculo.Items.Add("Cami�n");
            cbtipovehiculo.Items.Add("Motocicleta");
            cbtipovehiculo.SelectedIndex = 0;

            
            cbtipoinfo.Items.Add("Velocidad");
            cbtipoinfo.Items.Add("Tiempo de espera");
            cbtipoinfo.Items.Add("Flujo");
            cbtipoinfo.SelectedIndex = 0;

            logo.Image = Image.FromFile("D:\\Uso De Una Matriz De 3x3\\Uso De Una Matriz De 3x3\\imagen_2025-02-19_222936559-Photoroom.png");
            logo.SizeMode = PictureBoxSizeMode.StretchImage;
            logo.BackColor = Color.Transparent;
            this.BackgroundImage = Image.FromFile("D:\\Uso De Una Matriz De 3x3\\Uso De Una Matriz De 3x3\\Campistas-De-Casa-Rodante.png");
            this.BackgroundImageLayout = ImageLayout.Stretch;
            trafico.Image = Image.FromFile("D:\\Uso De Una Matriz De 3x3\\Uso De Una Matriz De 3x3\\concepto-isometrico-trafico-ciudad_1284-36614.png");
            trafico.SizeMode = PictureBoxSizeMode.StretchImage;


            btAgregarDatos.BackColor = Color.FromArgb(225, 19, 13);
            btAgregarDatos.FlatStyle = FlatStyle.Flat;
            btAgregarDatos.FlatAppearance.BorderColor = Color.FromArgb(88, 37, 39);
            btAgregarDatos.FlatAppearance.BorderSize = 1;
            btAgregarDatos.ForeColor = Color.White;

            gbInformacon.BackColor = Color.FromArgb(225, 185, 123);
            gbMatriz.BackColor = Color.FromArgb(225, 185, 123);
            gbMantenimiento.BackColor = Color.FromArgb(225, 185, 123);

            btCalcularTiempoPromedio.BackColor = Color.FromArgb(225, 19, 13);
            btCalcularTiempoPromedio.FlatStyle = FlatStyle.Flat;
            btCalcularTiempoPromedio.FlatAppearance.BorderColor = Color.FromArgb(88, 37, 39);
            btCalcularTiempoPromedio.FlatAppearance.BorderSize = 1;
            btCalcularTiempoPromedio.ForeColor = Color.White;

            btMostrarDatos.BackColor = Color.FromArgb(225, 19, 13);
            btMostrarDatos.FlatStyle = FlatStyle.Flat;
            btMostrarDatos.FlatAppearance.BorderColor = Color.FromArgb(88, 37, 39);
            btMostrarDatos.FlatAppearance.BorderSize = 1;
            btMostrarDatos.ForeColor = Color.White;

            btSimularAccidente.BackColor = Color.FromArgb(225, 19, 13);
            btSimularAccidente.FlatStyle = FlatStyle.Flat;
            btSimularAccidente.FlatAppearance.BorderColor = Color.FromArgb(88, 37, 39);
            btSimularAccidente.FlatAppearance.BorderSize = 1;
            btSimularAccidente.ForeColor = Color.White;


            btLimpiar.BackColor = Color.FromArgb(225, 19, 13);
            btLimpiar.FlatStyle = FlatStyle.Flat;
            btLimpiar.FlatAppearance.BorderColor = Color.FromArgb(88, 37, 39);
            btLimpiar.FlatAppearance.BorderSize = 1;
            btLimpiar.ForeColor = Color.White;

            Graficar.BackColor = Color.FromArgb(225, 19, 13);
            Graficar.FlatStyle = FlatStyle.Flat;
            Graficar.FlatAppearance.BorderColor = Color.FromArgb(88, 37, 39);
            Graficar.FlatAppearance.BorderSize = 1;
            Graficar.ForeColor = Color.White;


            Titulo.BackColor = Color.Transparent;


            //metodo para cambiar tipo de letra y tama�o
            using (Font font = new Font("Calibri", 10.0f))
            {
                Lbdig_info.Font = font;
                Lbtipo_info.Font = font;
                label1.Font = font;
                label2.Font = font;

                cbtipoinfo.Font = font;
                cbtipovehiculo.Font = font;


            }
            using (Font font = new Font("Calibri", 20.0f))
            { 
                Titulo.Font = font;
            }



            }

        private void btAgregarDatos_Click(object sender, EventArgs e)
        {
           
            if (string.IsNullOrEmpty(txtInterseccion.Text) || string.IsNullOrEmpty(txtValor.Text) || string.IsNullOrEmpty(txtValorVehiculo.Text))
            {
                MessageBox.Show("Por favor, complete todos los campos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            
            if (!int.TryParse(txtInterseccion.Text, out int interseccion) || interseccion < 0 || interseccion >= 10)
            {
                MessageBox.Show("La intersecci�n debe ser un n�mero entre 0 y 9.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            
            if (!double.TryParse(txtValor.Text, out double valor) || valor < 0)
            {
                MessageBox.Show("El valor debe ser un n�mero positivo.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

           
            if (!int.TryParse(txtValorVehiculo.Text, out int cantidadVehiculos) || cantidadVehiculos < 0)
            {
                MessageBox.Show("La cantidad de veh�culos debe ser un n�mero positivo.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int tipoVehiculo = cbtipovehiculo.SelectedIndex;

            
            switch (cbtipoinfo.SelectedItem.ToString())
            {
                case "Velocidad":
                    matrizTrafico[interseccion, tipoVehiculo].Velocidad = valor;
                    matrizTrafico[interseccion, tipoVehiculo].CantidadVehiculos = cantidadVehiculos; 
                    MessageBox.Show("Velocidad y cantidad de veh�culos agregadas correctamente.");
                    break;

                case "Tiempo de espera":
                    matrizTrafico[interseccion, tipoVehiculo].TiempoEspera = valor;
                    matrizTrafico[interseccion, tipoVehiculo].CantidadVehiculos = cantidadVehiculos; 
                    MessageBox.Show("Tiempo de espera y cantidad de veh�culos agregados correctamente.");
                    break;

                case "Flujo":
                    matrizTrafico[interseccion, tipoVehiculo].Flujo = valor;
                    matrizTrafico[interseccion, tipoVehiculo].CantidadVehiculos = cantidadVehiculos; 
                    MessageBox.Show("Flujo y cantidad de veh�culos agregados correctamente.");
                    break;

                default:
                    MessageBox.Show("Seleccione una opci�n v�lida.");
                    break;
            }

          
            txtInterseccion.Clear();
            txtValor.Clear();
            txtValorVehiculo.Clear();
        }
        //Funci�n para mostrar los datos en la tabla
        private void btMostrarDatos_Click(object sender, EventArgs e)
        {
            dgdatos.Columns.Clear();
            dgdatos.ColumnCount = 7; //
            dgdatos.Columns[0].Name = "Intersecci�n";
            dgdatos.Columns[1].Name = "Tipo de veh�culo";
            dgdatos.Columns[2].Name = "Velocidad (km/h)";
            dgdatos.Columns[3].Name = "Tiempo de espera (min)";
            dgdatos.Columns[4].Name = "Flujo (veh�culos/h)";
            dgdatos.Columns[5].Name = "Cantidad de veh�culos";
            dgdatos.Columns[6].Name = "Fecha"; 

            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    //se agregan los items a la tabla
                    dgdatos.Rows.Add();
                    int rowIndex = dgdatos.Rows.Count - 1;
                    dgdatos.Rows[rowIndex].Cells[0].Value = i;
                    dgdatos.Rows[rowIndex].Cells[1].Value = cbtipovehiculo.Items[j]; 
                    dgdatos.Rows[rowIndex].Cells[2].Value = matrizTrafico[i, j].Velocidad; 
                    dgdatos.Rows[rowIndex].Cells[3].Value = matrizTrafico[i, j].TiempoEspera; 
                    dgdatos.Rows[rowIndex].Cells[4].Value = matrizTrafico[i, j].Flujo;
                    dgdatos.Rows[rowIndex].Cells[5].Value = matrizTrafico[i, j].CantidadVehiculos; 
                    dgdatos.Rows[rowIndex].Cells[6].Value = DateTime.Now.ToString("dd/MM/yyyy"); 
                }
            }

            
            dgdatos.Rows.Clear();

            // Si no hay columnas, se agregan nuevas
            if (dgdatos.ColumnCount == 0)
            {
                dgdatos.ColumnCount = 7;
                dgdatos.Columns[0].Name = "Intersecci�n";
                dgdatos.Columns[1].Name = "Tipo de veh�culo";
                dgdatos.Columns[2].Name = "Velocidad (km/h)";
                dgdatos.Columns[3].Name = "Tiempo de espera (min)";
                dgdatos.Columns[4].Name = "Flujo (veh�culos/h)";
                dgdatos.Columns[5].Name = "Cantidad de veh�culos"; // Nueva columna
                dgdatos.Columns[6].Name = "Fecha"; // Columna de fecha
            }

            
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    var dato = matrizTrafico[i, j];

                    // Verificar si hay alg�n dato diferente de 0 antes de agregar la fila
                    if (dato.Velocidad != 0 || dato.TiempoEspera != 0 || dato.Flujo != 0 || dato.CantidadVehiculos != 0)
                    {
                        dgdatos.Rows.Add(i, cbtipovehiculo.Items[j], dato.Velocidad, dato.TiempoEspera, dato.Flujo, dato.CantidadVehiculos, DateTime.Now.ToString("dd/MM/yyyy"));
                    }
                }
            }

            
            if (dgdatos.Rows.Count == 0)
            {
                MessageBox.Show("No hay datos para mostrar.", "Informaci�n", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        //funci�n para limpiar los datos en la tabla
        private void btLimpiar_Click(object sender, EventArgs e)
        {
            dgdatos.Rows.Clear();
            dgdatos.Columns.Clear();

            // Reiniciar la matriz
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    matrizTrafico[i, j] = new ParametrosTrafico();
                }
            }

            MessageBox.Show("Datos limpiados correctamente.");
        }

        private void btCalcularTiempoPromedio_Click(object sender, EventArgs e)
        {
            double sumaTiempos = 0;
            int contador = 0;

            // Recorrer la matriz para sumar los tiempos de espera
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (matrizTrafico[i, j].TiempoEspera > 0) 
                    {
                        sumaTiempos += matrizTrafico[i, j].TiempoEspera;
                        contador++;
                    }
                }
            }

            // Calcular el promedio si hay datos v�lidos
            if (contador > 0)
            {
                double promedio = sumaTiempos / contador;
                MessageBox.Show($"El tiempo de espera promedio en todas las intersecciones es: {promedio:F2} minutos",
                                "Promedio de Tiempo de Espera", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("No hay datos suficientes para calcular un promedio.",
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btSimularAccidente_Click(object sender, EventArgs e)
        {
            Random rand = new Random();
            List<int> interseccionesValidas = new List<int>();

            // Buscar intersecciones con al menos un dato registrado
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (matrizTrafico[i, j].Velocidad != 0 || matrizTrafico[i, j].TiempoEspera != 0 || matrizTrafico[i, j].Flujo != 0)
                    {
                        interseccionesValidas.Add(i);
                        break; 
                    }
                }
            }

            
            if (interseccionesValidas.Count == 0)
            {
                MessageBox.Show("No hay intersecciones con datos registrados. No se puede simular un accidente.",
                                "Simulaci�n de tr�fico", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Seleccionar una intersecci�n aleatoria entre las disponibles
            int interseccionAfectada = interseccionesValidas[rand.Next(interseccionesValidas.Count)];

            for (int j = 0; j < 3; j++) 
            {
                ParametrosTrafico datos = matrizTrafico[interseccionAfectada, j];

                
                datos.Velocidad *= rand.Next(50, 70) / 100.0;  // Reducir velocidad (30% a 50%)
                datos.TiempoEspera *= rand.Next(130, 170) / 100.0;  // Aumentar tiempo de espera (30% a 70%)
                datos.Flujo *= rand.Next(50, 80) / 100.0;  // Reducir flujo de veh�culos (20% a 50%)
            }

            MessageBox.Show($"Un accidente/semaforo da�ado ocurri� en la intersecci�n {interseccionAfectada}. Los datos han sido ajustados.",
                            "Simulaci�n de tr�fico", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            btMostrarDatos_Click(sender, e);
        }

        private void Graficar_Click(object sender, EventArgs e)
        {

            double[] flujos = new double[10];

            // Obtener los datos promedio de cada intersecci�n
            for (int i = 0; i < 10; i++)
            {
                double sumaFlujo = 0;
                int contador = 0;

                for (int j = 0; j < 3; j++)
                {
                    if (matrizTrafico[i, j].Flujo != 0)
                    {

                        sumaFlujo += matrizTrafico[i, j].Flujo;
                        contador++;
                    }
                }

                if (contador > 0)
                {

                    flujos[i] = sumaFlujo / contador;
                }
            }

            
            Form2 grafico = new Form2();
            grafico.GraficarDatos(flujos);
            grafico.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        private void Actualizar_Click(object sender, EventArgs e)
        {
            
            if (!int.TryParse(txtInterseccion.Text, out int interseccion) || interseccion < 0 || interseccion >= 10)
            {
                MessageBox.Show("Ingrese una intersecci�n v�lida (0-9).", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int tipoVehiculo = cbtipovehiculo.SelectedIndex;

            
            ParametrosTrafico datosActuales = matrizTrafico[interseccion, tipoVehiculo];

            // Mostrar los valores en los campos de texto
            txtValor.Text = datosActuales.Velocidad.ToString();
            txtValorVehiculo.Text = datosActuales.CantidadVehiculos.ToString();

            MessageBox.Show("Datos actualizados en los campos.", "Informaci�n", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}


