﻿namespace Uso_De_Una_Matriz_De_3x3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            gbInformacon = new GroupBox();
            Actualizar = new Button();
            txtValorVehiculo = new TextBox();
            label3 = new Label();
            dateTimePicker1 = new DateTimePicker();
            txtValor = new TextBox();
            label2 = new Label();
            cbtipoinfo = new ComboBox();
            label1 = new Label();
            txtInterseccion = new TextBox();
            cbtipovehiculo = new ComboBox();
            Lbdig_info = new Label();
            Lbtipo_info = new Label();
            gbMatriz = new GroupBox();
            Graficar = new Button();
            btSimularAccidente = new Button();
            btMostrarDatos = new Button();
            btLimpiar = new Button();
            btAgregarDatos = new Button();
            btCalcularTiempoPromedio = new Button();
            gbMantenimiento = new GroupBox();
            dgdatos = new DataGridView();
            logo = new PictureBox();
            Titulo = new Label();
            trafico = new PictureBox();
            gbInformacon.SuspendLayout();
            gbMatriz.SuspendLayout();
            gbMantenimiento.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgdatos).BeginInit();
            ((System.ComponentModel.ISupportInitialize)logo).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trafico).BeginInit();
            SuspendLayout();
            // 
            // gbInformacon
            // 
            gbInformacon.Controls.Add(Actualizar);
            gbInformacon.Controls.Add(txtValorVehiculo);
            gbInformacon.Controls.Add(label3);
            gbInformacon.Controls.Add(dateTimePicker1);
            gbInformacon.Controls.Add(txtValor);
            gbInformacon.Controls.Add(label2);
            gbInformacon.Controls.Add(cbtipoinfo);
            gbInformacon.Controls.Add(label1);
            gbInformacon.Controls.Add(txtInterseccion);
            gbInformacon.Controls.Add(cbtipovehiculo);
            gbInformacon.Controls.Add(Lbdig_info);
            gbInformacon.Controls.Add(Lbtipo_info);
            gbInformacon.Location = new Point(223, 65);
            gbInformacon.Name = "gbInformacon";
            gbInformacon.Size = new Size(402, 275);
            gbInformacon.TabIndex = 2;
            gbInformacon.TabStop = false;
            // 
            // Actualizar
            // 
            Actualizar.Location = new Point(6, 233);
            Actualizar.Name = "Actualizar";
            Actualizar.Size = new Size(94, 29);
            Actualizar.TabIndex = 15;
            Actualizar.Text = "Actualizar";
            Actualizar.UseVisualStyleBackColor = true;
            Actualizar.Click += Actualizar_Click;
            // 
            // txtValorVehiculo
            // 
            txtValorVehiculo.Location = new Point(163, 193);
            txtValorVehiculo.Name = "txtValorVehiculo";
            txtValorVehiculo.Size = new Size(204, 27);
            txtValorVehiculo.TabIndex = 14;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(6, 196);
            label3.Name = "label3";
            label3.Size = new Size(108, 20);
            label3.TabIndex = 13;
            label3.Text = "Valor vehículos";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(117, 232);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(250, 27);
            dateTimePicker1.TabIndex = 12;
            // 
            // txtValor
            // 
            txtValor.Location = new Point(163, 113);
            txtValor.Name = "txtValor";
            txtValor.Size = new Size(204, 27);
            txtValor.TabIndex = 11;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 116);
            label2.Name = "label2";
            label2.Size = new Size(127, 20);
            label2.TabIndex = 10;
            label2.Text = "Valor información";
            // 
            // cbtipoinfo
            // 
            cbtipoinfo.FormattingEnabled = true;
            cbtipoinfo.Location = new Point(163, 61);
            cbtipoinfo.Name = "cbtipoinfo";
            cbtipoinfo.Size = new Size(204, 28);
            cbtipoinfo.TabIndex = 9;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(6, 155);
            label1.Name = "label1";
            label1.Size = new Size(119, 20);
            label1.TabIndex = 8;
            label1.Text = "Tipo de vehículo";
            // 
            // txtInterseccion
            // 
            txtInterseccion.Location = new Point(163, 20);
            txtInterseccion.Name = "txtInterseccion";
            txtInterseccion.Size = new Size(204, 27);
            txtInterseccion.TabIndex = 7;
            // 
            // cbtipovehiculo
            // 
            cbtipovehiculo.FormattingEnabled = true;
            cbtipovehiculo.Location = new Point(163, 152);
            cbtipovehiculo.Name = "cbtipovehiculo";
            cbtipovehiculo.Size = new Size(204, 28);
            cbtipovehiculo.TabIndex = 6;
            // 
            // Lbdig_info
            // 
            Lbdig_info.AutoSize = true;
            Lbdig_info.Location = new Point(6, 23);
            Lbdig_info.Name = "Lbdig_info";
            Lbdig_info.Size = new Size(88, 20);
            Lbdig_info.TabIndex = 1;
            Lbdig_info.Text = "Intersección";
            // 
            // Lbtipo_info
            // 
            Lbtipo_info.AutoSize = true;
            Lbtipo_info.Location = new Point(6, 61);
            Lbtipo_info.Name = "Lbtipo_info";
            Lbtipo_info.Size = new Size(144, 20);
            Lbtipo_info.TabIndex = 0;
            Lbtipo_info.Text = "Tipo de información";
            // 
            // gbMatriz
            // 
            gbMatriz.Controls.Add(Graficar);
            gbMatriz.Controls.Add(btSimularAccidente);
            gbMatriz.Controls.Add(btMostrarDatos);
            gbMatriz.Controls.Add(btLimpiar);
            gbMatriz.Controls.Add(btAgregarDatos);
            gbMatriz.Controls.Add(btCalcularTiempoPromedio);
            gbMatriz.Location = new Point(645, 79);
            gbMatriz.Name = "gbMatriz";
            gbMatriz.Size = new Size(312, 161);
            gbMatriz.TabIndex = 3;
            gbMatriz.TabStop = false;
            // 
            // Graficar
            // 
            Graficar.Location = new Point(208, 89);
            Graficar.Name = "Graficar";
            Graficar.Size = new Size(94, 51);
            Graficar.TabIndex = 8;
            Graficar.Text = "Graficar";
            Graficar.UseVisualStyleBackColor = true;
            Graficar.Click += Graficar_Click;
            // 
            // btSimularAccidente
            // 
            btSimularAccidente.Location = new Point(7, 91);
            btSimularAccidente.Name = "btSimularAccidente";
            btSimularAccidente.Size = new Size(94, 49);
            btSimularAccidente.TabIndex = 7;
            btSimularAccidente.Text = "Simular";
            btSimularAccidente.UseVisualStyleBackColor = true;
            btSimularAccidente.Click += btSimularAccidente_Click;
            // 
            // btMostrarDatos
            // 
            btMostrarDatos.Location = new Point(107, 27);
            btMostrarDatos.Name = "btMostrarDatos";
            btMostrarDatos.Size = new Size(94, 49);
            btMostrarDatos.TabIndex = 6;
            btMostrarDatos.Text = "Mostrar";
            btMostrarDatos.UseVisualStyleBackColor = true;
            btMostrarDatos.Click += btMostrarDatos_Click;
            // 
            // btLimpiar
            // 
            btLimpiar.Location = new Point(107, 91);
            btLimpiar.Name = "btLimpiar";
            btLimpiar.Size = new Size(94, 49);
            btLimpiar.TabIndex = 5;
            btLimpiar.Text = "Limpiar";
            btLimpiar.UseVisualStyleBackColor = true;
            btLimpiar.Click += btLimpiar_Click;
            // 
            // btAgregarDatos
            // 
            btAgregarDatos.Location = new Point(7, 27);
            btAgregarDatos.Name = "btAgregarDatos";
            btAgregarDatos.Size = new Size(94, 49);
            btAgregarDatos.TabIndex = 5;
            btAgregarDatos.Text = "&Agregar";
            btAgregarDatos.UseVisualStyleBackColor = true;
            btAgregarDatos.Click += btAgregarDatos_Click;
            // 
            // btCalcularTiempoPromedio
            // 
            btCalcularTiempoPromedio.Location = new Point(208, 27);
            btCalcularTiempoPromedio.Name = "btCalcularTiempoPromedio";
            btCalcularTiempoPromedio.Size = new Size(94, 49);
            btCalcularTiempoPromedio.TabIndex = 3;
            btCalcularTiempoPromedio.Text = "Promedio";
            btCalcularTiempoPromedio.UseVisualStyleBackColor = true;
            btCalcularTiempoPromedio.Click += btCalcularTiempoPromedio_Click;
            // 
            // gbMantenimiento
            // 
            gbMantenimiento.Controls.Add(dgdatos);
            gbMantenimiento.Location = new Point(223, 359);
            gbMantenimiento.Name = "gbMantenimiento";
            gbMantenimiento.Size = new Size(773, 211);
            gbMantenimiento.TabIndex = 4;
            gbMantenimiento.TabStop = false;
            // 
            // dgdatos
            // 
            dgdatos.BackgroundColor = SystemColors.Control;
            dgdatos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgdatos.Location = new Point(6, 17);
            dgdatos.Name = "dgdatos";
            dgdatos.RowHeadersWidth = 51;
            dgdatos.Size = new Size(760, 188);
            dgdatos.TabIndex = 0;
            // 
            // logo
            // 
            logo.Location = new Point(14, 79);
            logo.Margin = new Padding(3, 4, 3, 4);
            logo.Name = "logo";
            logo.Size = new Size(160, 188);
            logo.TabIndex = 5;
            logo.TabStop = false;
            // 
            // Titulo
            // 
            Titulo.AutoSize = true;
            Titulo.Location = new Point(418, 12);
            Titulo.Name = "Titulo";
            Titulo.Size = new Size(107, 20);
            Titulo.TabIndex = 6;
            Titulo.Text = "Trafico Urbano";
            // 
            // trafico
            // 
            trafico.Location = new Point(12, 309);
            trafico.Margin = new Padding(3, 4, 3, 4);
            trafico.Name = "trafico";
            trafico.Size = new Size(203, 255);
            trafico.TabIndex = 7;
            trafico.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1015, 593);
            Controls.Add(trafico);
            Controls.Add(Titulo);
            Controls.Add(logo);
            Controls.Add(gbMantenimiento);
            Controls.Add(gbMatriz);
            Controls.Add(gbInformacon);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            gbInformacon.ResumeLayout(false);
            gbInformacon.PerformLayout();
            gbMatriz.ResumeLayout(false);
            gbMantenimiento.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgdatos).EndInit();
            ((System.ComponentModel.ISupportInitialize)logo).EndInit();
            ((System.ComponentModel.ISupportInitialize)trafico).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private GroupBox gbInformacon;
        private GroupBox gbMatriz;
        private GroupBox gbMantenimiento;
        private TextBox textBox2;
        private TextBox txtValor;
        private ListBox listBox1;
        private Label Lbdig_info;
        private Label Lbtipo_info;
        private Button btCalcularTiempoPromedio;
        private Button button3;
        private Button button2;
        private Button button1;
        private DataGridView dgdatos;
        private ComboBox cbtipovehiculo;
        private TextBox txtInterseccion;
        private Button btMostrarDatos;
        private Button btLimpiar;
        private Button btAgregarDatos;
        private Label label1;
        private ComboBox cbtipoinfo;
        private Label label2;
        private Button btSimularAccidente;
        private Button Graficar;
        private PictureBox logo;
        private DateTimePicker dateTimePicker1;
        private TextBox txtValorVehiculo;
        private Label label3;
        private Button Actualizar;
        private Label Titulo;
        private PictureBox trafico;
    }
}
