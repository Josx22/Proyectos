﻿using System;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using Microsoft.VisualBasic.Logging;

namespace Uso_De_Una_Matriz_De_3x3
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            this.BackColor = Color.FromArgb(235, 235, 235);

            Volver.BackColor = Color.FromArgb(225, 19, 13);
            Volver.FlatStyle = FlatStyle.Flat;
            Volver.FlatAppearance.BorderColor = Color.FromArgb(88, 37, 39);
            Volver.FlatAppearance.BorderSize = 1;
            Volver.ForeColor = Color.White;

            this.BackgroundImage = Image.FromFile("D:\\Uso De Una Matriz De 3x3\\Uso De Una Matriz De 3x3\\Campistas-De-Casa-Rodante.png");
            this.BackgroundImageLayout = ImageLayout.Stretch;


        }

        public void GraficarDatos(double[] flujos)
        {
            chart1.Series.Clear();
            chart1.Titles.Clear();

            
            chart1.ChartAreas[0].AxisX.Interval = 1;
            chart1.ChartAreas[0].AxisY.Title = "Vehículos/hora";
            chart1.ChartAreas[0].AxisX.Title = "Intersecciones";

            
            chart1.Titles.Add("Flujo Vehicular por Intersección");

            // Crear una serie para el flujo vehicular
            Series serieFlujo = new Series("Flujo Vehicular");
            serieFlujo.ChartType = SeriesChartType.Column; // Se representará como columna
            serieFlujo.Color = Color.FromArgb(255, 105, 97);
            chart1.Series.Add(serieFlujo);

            
            chart1.ChartAreas[0].AxisX.LabelStyle.IsStaggered = false; //evitar sobreposicionamiento

            
            for (int i = 0; i < 10; i++) 
            {
                // Usar el índice como valor X para separar las columnas
                DataPoint punto = new DataPoint(i, flujos[i]); 
                punto.AxisLabel = $"Intersección {i}";
                punto.Label = flujos[i].ToString("F1"); 
                serieFlujo.Points.Add(punto);
            }   

            // Asegurar que se muestren todas las etiquetas del eje X
            chart1.ChartAreas[0].AxisX.Interval = 1; 
            chart1.ChartAreas[0].AxisX.IntervalOffset = 0; 

           
            chart1.ChartAreas[0].AxisY.MajorGrid.LineColor = Color.LightGray;
            chart1.ChartAreas[0].AxisX.MajorGrid.LineColor = Color.LightGray;
            chart1.ChartAreas[0].BackColor = Color.FromArgb(255, 236, 217);
        }

        private void Volver_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}