﻿namespace Uso_De_Una_Matriz_De_3x3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            gbInformacon = new GroupBox();
            txtEdad = new TextBox();
            txtInfo = new TextBox();
            cbtipoinfo = new ComboBox();
            lbedad = new Label();
            Lbdig_info = new Label();
            Lbtipo_info = new Label();
            gbMatriz = new GroupBox();
            btMostrar = new Button();
            btLimpiar = new Button();
            btAgregar = new Button();
            button5 = new Button();
            btPromedio = new Button();
            gbMantenimiento = new GroupBox();
            dgdatos = new DataGridView();
            gbInformacon.SuspendLayout();
            gbMatriz.SuspendLayout();
            gbMantenimiento.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgdatos).BeginInit();
            SuspendLayout();
            // 
            // gbInformacon
            // 
            gbInformacon.Controls.Add(txtEdad);
            gbInformacon.Controls.Add(txtInfo);
            gbInformacon.Controls.Add(cbtipoinfo);
            gbInformacon.Controls.Add(lbedad);
            gbInformacon.Controls.Add(Lbdig_info);
            gbInformacon.Controls.Add(Lbtipo_info);
            gbInformacon.Location = new Point(34, 33);
            gbInformacon.Name = "gbInformacon";
            gbInformacon.Size = new Size(357, 193);
            gbInformacon.TabIndex = 2;
            gbInformacon.TabStop = false;
            gbInformacon.Text = "groupBox1";
            // 
            // txtEdad
            // 
            txtEdad.Location = new Point(153, 132);
            txtEdad.Name = "txtEdad";
            txtEdad.Size = new Size(117, 27);
            txtEdad.TabIndex = 8;
            // 
            // txtInfo
            // 
            txtInfo.Location = new Point(153, 85);
            txtInfo.Name = "txtInfo";
            txtInfo.Size = new Size(204, 27);
            txtInfo.TabIndex = 7;
            // 
            // cbtipoinfo
            // 
            cbtipoinfo.FormattingEnabled = true;
            cbtipoinfo.Items.AddRange(new object[] { "Nombre", "Apellido" });
            cbtipoinfo.Location = new Point(153, 39);
            cbtipoinfo.Name = "cbtipoinfo";
            cbtipoinfo.Size = new Size(204, 28);
            cbtipoinfo.TabIndex = 6;
            // 
            // lbedad
            // 
            lbedad.AutoSize = true;
            lbedad.Location = new Point(3, 132);
            lbedad.Name = "lbedad";
            lbedad.Size = new Size(43, 20);
            lbedad.TabIndex = 2;
            lbedad.Text = "Edad";
            // 
            // Lbdig_info
            // 
            Lbdig_info.AutoSize = true;
            Lbdig_info.Location = new Point(3, 88);
            Lbdig_info.Name = "Lbdig_info";
            Lbdig_info.Size = new Size(150, 20);
            Lbdig_info.TabIndex = 1;
            Lbdig_info.Text = "Digite la informacion";
            // 
            // Lbtipo_info
            // 
            Lbtipo_info.AutoSize = true;
            Lbtipo_info.Location = new Point(3, 42);
            Lbtipo_info.Name = "Lbtipo_info";
            Lbtipo_info.Size = new Size(144, 20);
            Lbtipo_info.TabIndex = 0;
            Lbtipo_info.Text = "Tipo de informacion";
            // 
            // gbMatriz
            // 
            gbMatriz.Controls.Add(btMostrar);
            gbMatriz.Controls.Add(btLimpiar);
            gbMatriz.Controls.Add(btAgregar);
            gbMatriz.Controls.Add(button5);
            gbMatriz.Controls.Add(btPromedio);
            gbMatriz.Location = new Point(412, 33);
            gbMatriz.Name = "gbMatriz";
            gbMatriz.Size = new Size(357, 193);
            gbMatriz.TabIndex = 3;
            gbMatriz.TabStop = false;
            gbMatriz.Text = "groupBox2";
            // 
            // btMostrar
            // 
            btMostrar.Location = new Point(219, 47);
            btMostrar.Name = "btMostrar";
            btMostrar.Size = new Size(94, 29);
            btMostrar.TabIndex = 6;
            btMostrar.Text = "Mostrar Matriz";
            btMostrar.UseVisualStyleBackColor = true;
            btMostrar.Click += btMostrar_Click;
            // 
            // btLimpiar
            // 
            btLimpiar.Location = new Point(40, 102);
            btLimpiar.Name = "btLimpiar";
            btLimpiar.Size = new Size(94, 29);
            btLimpiar.TabIndex = 5;
            btLimpiar.Text = "Limpiar Matriz";
            btLimpiar.UseVisualStyleBackColor = true;
            btLimpiar.Click += btLimpiar_Click;
            // 
            // btAgregar
            // 
            btAgregar.Location = new Point(40, 47);
            btAgregar.Name = "btAgregar";
            btAgregar.Size = new Size(94, 29);
            btAgregar.TabIndex = 5;
            btAgregar.Text = "&Agregar";
            btAgregar.UseVisualStyleBackColor = true;
            btAgregar.Click += btAgregar_Click;
            // 
            // button5
            // 
            button5.Location = new Point(40, 158);
            button5.Name = "button5";
            button5.Size = new Size(94, 29);
            button5.TabIndex = 4;
            button5.Text = "salir";
            button5.UseVisualStyleBackColor = true;
            // 
            // btPromedio
            // 
            btPromedio.Location = new Point(219, 102);
            btPromedio.Name = "btPromedio";
            btPromedio.Size = new Size(94, 29);
            btPromedio.TabIndex = 3;
            btPromedio.Text = "Promedio";
            btPromedio.UseVisualStyleBackColor = true;
            // 
            // gbMantenimiento
            // 
            gbMantenimiento.Controls.Add(dgdatos);
            gbMantenimiento.Location = new Point(34, 245);
            gbMantenimiento.Name = "gbMantenimiento";
            gbMantenimiento.Size = new Size(735, 193);
            gbMantenimiento.TabIndex = 4;
            gbMantenimiento.TabStop = false;
            gbMantenimiento.Text = "groupBox3";
            // 
            // dgdatos
            // 
            dgdatos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgdatos.Location = new Point(6, 26);
            dgdatos.Name = "dgdatos";
            dgdatos.RowHeadersWidth = 51;
            dgdatos.Size = new Size(723, 161);
            dgdatos.TabIndex = 0;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(gbMantenimiento);
            Controls.Add(gbMatriz);
            Controls.Add(gbInformacon);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            gbInformacon.ResumeLayout(false);
            gbInformacon.PerformLayout();
            gbMatriz.ResumeLayout(false);
            gbMantenimiento.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgdatos).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private GroupBox gbInformacon;
        private GroupBox gbMatriz;
        private GroupBox gbMantenimiento;
        private TextBox textBox2;
        private TextBox textBox1;
        private ListBox listBox1;
        private Label lbedad;
        private Label Lbdig_info;
        private Label Lbtipo_info;
        private Button button5;
        private Button btPromedio;
        private Button button3;
        private Button button2;
        private Button button1;
        private DataGridView dgdatos;
        private ComboBox cbtipoinfo;
        private TextBox txtInfo;
        private TextBox txtEdad;
        private Button btMostrar;
        private Button btLimpiar;
        private Button btAgregar;
    }
}
